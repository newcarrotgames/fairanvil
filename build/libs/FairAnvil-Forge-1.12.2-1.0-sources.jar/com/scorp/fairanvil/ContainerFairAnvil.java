package com.scorp.fairanvil;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import net.minecraft.block.BlockAnvil;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.ContainerRepair;
import net.minecraft.inventory.IContainerListener;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemEnchantedBook;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.AnvilUpdateEvent;

/**
 * A drop-in replacement for the vanilla anvil container that:
 * <ul>
 *   <li>removes the "Too Expensive!" 40-level limit, and</li>
 *   <li>charges a flat XP-point cost (see {@link Experience}) instead of scaling levels.</li>
 * </ul>
 *
 * <p>The combine/repair maths mirror vanilla {@code ContainerRepair#updateRepairOutput} so that
 * RLCraft's enchantments behave exactly as the pack expects; only the cost gate and the level
 * deduction are changed. {@link AnvilUpdateEvent} is still posted so other mods that add anvil
 * recipes keep working.
 */
public class ContainerFairAnvil extends ContainerRepair {

    private final World world;
    private final BlockPos pos;
    private final EntityPlayer user;
    private final IInventory inputInv;
    private final IInventory outputInv;

    /** Level cost actually shown and charged (clamped per hideTooExpensive); drives the XP-point cost. */
    private int costLevels;
    /** Number of repair-material items consumed from the second input slot. */
    private int matCost;
    private String repairName = "";

    public ContainerFairAnvil(InventoryPlayer playerInv, World world, BlockPos pos, EntityPlayer player) {
        super(playerInv, world, pos, player);
        this.world = world;
        this.pos = pos;
        this.user = player;
        this.inputInv = this.field_75151_b.get(0).field_75224_c;
        this.outputInv = this.field_75151_b.get(2).field_75224_c;

        // Swap the vanilla output slot (which deducts whole levels) for our point-based one.
        FairOutputSlot output = new FairOutputSlot(this.outputInv, 0, 134, 47);
        output.field_75222_d = 2;
        this.field_75151_b.set(2, output);
    }

    @Override
    public void func_82850_a(String newName) {
        this.repairName = newName == null ? "" : newName;
        this.func_82848_d();
    }

    @Override
    public ItemStack func_82846_b(EntityPlayer playerIn, int index) {
        // Stop shift-clicking the result when the player cannot afford it (vanilla's transfer path
        // would otherwise bypass the point check).
        Slot slot = this.field_75151_b.get(index);
        if (index == 2 && slot != null && slot.func_75216_d() && !slot.func_82869_a(playerIn)) {
            return ItemStack.field_190927_a;
        }
        return super.func_82846_b(playerIn, index);
    }

    @Override
    public void func_82848_d() {
        ItemStack itemstack = this.inputInv.func_70301_a(0);
        this.costLevels = 0;
        int i = 0;
        int j = 0;
        int k = 0;

        // Mod compatibility: let other mods (or RLCraft) supply or cancel the anvil result.
        AnvilUpdateEvent event = new AnvilUpdateEvent(itemstack, this.inputInv.func_70301_a(1), this.repairName, 0);
        if (MinecraftForge.EVENT_BUS.post(event)) {
            this.outputInv.func_70299_a(0, ItemStack.field_190927_a);
            this.applyCost(0);
            return;
        }
        if (!event.getOutput().func_190926_b()) {
            this.outputInv.func_70299_a(0, event.getOutput());
            this.matCost = event.getMaterialCost();
            this.applyCost(event.getCost());
            return;
        }

        if (itemstack.func_190926_b()) {
            this.outputInv.func_70299_a(0, ItemStack.field_190927_a);
            this.applyCost(0);
            return;
        }

        ItemStack itemstack1 = itemstack.func_77946_l();
        ItemStack itemstack2 = this.inputInv.func_70301_a(1);
        Map<Enchantment, Integer> map = EnchantmentHelper.func_82781_a(itemstack1);
        boolean flag = false;
        j = j + itemstack.func_82838_A() + (itemstack2.func_190926_b() ? 0 : itemstack2.func_82838_A());
        this.matCost = 0;

        if (!itemstack2.func_190926_b()) {
            flag = itemstack2.func_77973_b() == Items.field_151134_bR && ItemEnchantedBook.func_92110_g(itemstack2).func_74745_c() > 0;

            if (itemstack1.func_77984_f() && itemstack1.func_77973_b().func_82789_a(itemstack, itemstack2)) {
                int l2 = Math.min(itemstack1.func_77952_i(), itemstack1.func_77958_k() / 4);

                if (l2 <= 0) {
                    this.outputInv.func_70299_a(0, ItemStack.field_190927_a);
                    this.applyCost(0);
                    return;
                }

                int i3;
                for (i3 = 0; l2 > 0 && i3 < itemstack2.func_190916_E(); ++i3) {
                    int j3 = itemstack1.func_77952_i() - l2;
                    itemstack1.func_77964_b(j3);
                    ++i;
                    l2 = Math.min(itemstack1.func_77952_i(), itemstack1.func_77958_k() / 4);
                }

                this.matCost = i3;
            } else {
                if (!flag && (itemstack1.func_77973_b() != itemstack2.func_77973_b() || !itemstack1.func_77984_f())) {
                    this.outputInv.func_70299_a(0, ItemStack.field_190927_a);
                    this.applyCost(0);
                    return;
                }

                if (itemstack1.func_77984_f() && !flag) {
                    int l = itemstack.func_77958_k() - itemstack.func_77952_i();
                    int i1 = itemstack2.func_77958_k() - itemstack2.func_77952_i();
                    int j1 = i1 + itemstack1.func_77958_k() * 12 / 100;
                    int k1 = l + j1;
                    int l1 = itemstack1.func_77958_k() - k1;

                    if (l1 < 0) {
                        l1 = 0;
                    }

                    if (l1 < itemstack1.func_77960_j()) {
                        itemstack1.func_77964_b(l1);
                        i += 2;
                    }
                }

                Map<Enchantment, Integer> map1 = EnchantmentHelper.func_82781_a(itemstack2);
                boolean flag2 = false;
                boolean flag3 = false;

                for (Enchantment enchantment1 : map1.keySet()) {
                    if (enchantment1 != null) {
                        int i2 = map.containsKey(enchantment1) ? map.get(enchantment1).intValue() : 0;
                        int j2 = map1.get(enchantment1).intValue();
                        j2 = i2 == j2 ? j2 + 1 : Math.max(j2, i2);
                        boolean flag1 = enchantment1.func_92089_a(itemstack);

                        if (this.user.field_71075_bZ.field_75098_d || itemstack.func_77973_b() == Items.field_151134_bR) {
                            flag1 = true;
                        }

                        for (Enchantment enchantment : map.keySet()) {
                            if (enchantment != enchantment1 && !enchantment1.func_191560_c(enchantment)) {
                                flag1 = false;
                                ++i;
                            }
                        }

                        if (!flag1) {
                            flag3 = true;
                        } else {
                            flag2 = true;

                            if (j2 > enchantment1.func_77325_b()) {
                                j2 = enchantment1.func_77325_b();
                            }

                            map.put(enchantment1, Integer.valueOf(j2));
                            int k3 = 0;

                            switch (enchantment1.func_77324_c()) {
                                case COMMON:
                                    k3 = 1;
                                    break;
                                case UNCOMMON:
                                    k3 = 2;
                                    break;
                                case RARE:
                                    k3 = 4;
                                    break;
                                case VERY_RARE:
                                    k3 = 8;
                            }

                            if (flag) {
                                k3 = Math.max(1, k3 / 2);
                            }

                            i += k3 * j2;

                            if (itemstack.func_190916_E() > 1) {
                                i = 40;
                            }
                        }
                    }
                }

                if (flag3 && !flag2) {
                    this.outputInv.func_70299_a(0, ItemStack.field_190927_a);
                    this.applyCost(0);
                    return;
                }
            }
        }

        if (StringUtils.isBlank(this.repairName)) {
            if (itemstack.func_82837_s()) {
                k = 1;
                i += k;
                itemstack1.func_135074_t();
            }
        } else if (!this.repairName.equals(itemstack.func_82833_r())) {
            k = 1;
            i += k;
            itemstack1.func_151001_c(this.repairName);
        }

        int cost = j + i;

        if (i <= 0) {
            itemstack1 = ItemStack.field_190927_a;
        }

        if (k == i && k > 0 && cost >= 40) {
            cost = 39;
        }

        // Vanilla clears the output here when cost >= 40 ("Too Expensive!"). FairAnvil keeps it.

        if (!itemstack1.func_190926_b()) {
            int k2 = itemstack1.func_82838_A();

            if (!itemstack2.func_190926_b() && k2 < itemstack2.func_82838_A()) {
                k2 = itemstack2.func_82838_A();
            }

            if (k != i || k == 0) {
                k2 = k2 * 2 + 1;
            }

            itemstack1.func_82841_c(k2);
            EnchantmentHelper.func_82782_a(map, itemstack1);
        }

        this.outputInv.func_70299_a(0, itemstack1);
        this.applyCost(cost);
    }

    /**
     * Sets the level cost that is BOTH shown to the client and used to derive the XP-point charge,
     * so the displayed price always matches what the player is actually charged.
     *
     * <p>When {@code hideTooExpensive} is on, the cost is clamped below 40 so the vanilla client never
     * renders "Too Expensive!" - and the point charge is clamped to match, otherwise an item that
     * looks affordable would be silently un-takeable for players who lack the (much larger) XP for the
     * true uncapped cost.
     */
    private void applyCost(int cost) {
        this.costLevels = FairAnvilMod.hideTooExpensive ? Math.min(cost, 39) : cost;
        this.field_82854_e = this.costLevels;
        for (IContainerListener listener : this.field_75149_d) {
            listener.func_71112_a(this, 0, this.field_82854_e);
        }
        this.func_75142_b();
    }

    /** Output slot that gates and charges in flat XP points instead of levels. */
    private class FairOutputSlot extends Slot {

        FairOutputSlot(IInventory inventoryIn, int index, int xPosition, int yPosition) {
            super(inventoryIn, index, xPosition, yPosition);
        }

        @Override
        public boolean func_75214_a(ItemStack stack) {
            return false;
        }

        @Override
        public boolean func_82869_a(EntityPlayer playerIn) {
            return (playerIn.field_71075_bZ.field_75098_d
                    || Experience.getTotalExperience(playerIn) >= Experience.getExpFromLevel(ContainerFairAnvil.this.costLevels))
                    && ContainerFairAnvil.this.costLevels > 0
                    && this.func_75216_d();
        }

        @Override
        public ItemStack func_190901_a(EntityPlayer thePlayer, ItemStack stack) {
            if (!thePlayer.field_71075_bZ.field_75098_d) {
                Experience.changeExp(thePlayer, -Experience.getExpFromLevel(ContainerFairAnvil.this.costLevels));
            }

            ContainerFairAnvil.this.inputInv.func_70299_a(0, ItemStack.field_190927_a);

            if (ContainerFairAnvil.this.matCost > 0) {
                ItemStack material = ContainerFairAnvil.this.inputInv.func_70301_a(1);

                if (!material.func_190926_b() && material.func_190916_E() > ContainerFairAnvil.this.matCost) {
                    material.func_190918_g(ContainerFairAnvil.this.matCost);
                    ContainerFairAnvil.this.inputInv.func_70299_a(1, material);
                } else {
                    ContainerFairAnvil.this.inputInv.func_70299_a(1, ItemStack.field_190927_a);
                }
            } else {
                ContainerFairAnvil.this.inputInv.func_70299_a(1, ItemStack.field_190927_a);
            }

            ContainerFairAnvil.this.field_82854_e = 0;
            ContainerFairAnvil.this.costLevels = 0;

            IBlockState state = ContainerFairAnvil.this.world.func_180495_p(ContainerFairAnvil.this.pos);

            if (!thePlayer.field_71075_bZ.field_75098_d && !ContainerFairAnvil.this.world.field_72995_K
                    && state.func_177230_c() == Blocks.field_150467_bQ && thePlayer.func_70681_au().nextFloat() < 0.12F) {
                int damage = state.func_177229_b(BlockAnvil.field_176505_b).intValue() + 1;

                if (damage > 2) {
                    ContainerFairAnvil.this.world.func_175698_g(ContainerFairAnvil.this.pos);
                    ContainerFairAnvil.this.world.func_175718_b(1029, ContainerFairAnvil.this.pos, 0);
                } else {
                    ContainerFairAnvil.this.world.func_180501_a(ContainerFairAnvil.this.pos,
                            state.func_177226_a(BlockAnvil.field_176505_b, Integer.valueOf(damage)), 2);
                    ContainerFairAnvil.this.world.func_175718_b(1030, ContainerFairAnvil.this.pos, 0);
                }
            } else if (!ContainerFairAnvil.this.world.field_72995_K) {
                ContainerFairAnvil.this.world.func_175718_b(1030, ContainerFairAnvil.this.pos, 0);
            }

            return stack;
        }
    }
}
