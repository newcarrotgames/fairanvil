package com.scorp.fairanvil;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.IInteractionObject;
import net.minecraft.world.World;

/**
 * Opens our {@link ContainerFairEnchantment} while reusing the vanilla
 * {@code minecraft:enchanting_table} GUI on the client (server-side only).
 */
public class FairEnchantInteractionObject implements IInteractionObject {

    private final World world;
    private final BlockPos pos;

    public FairEnchantInteractionObject(World world, BlockPos pos) {
        this.world = world;
        this.pos = pos;
    }

    @Override
    public Container func_174876_a(InventoryPlayer playerInventory, EntityPlayer playerIn) {
        return new ContainerFairEnchantment(playerInventory, this.world, this.pos);
    }

    @Override
    public String func_174875_k() {
        return "minecraft:enchanting_table";
    }

    @Override
    public String func_70005_c_() {
        return "container.enchant";
    }

    @Override
    public boolean func_145818_k_() {
        return false;
    }

    @Override
    public ITextComponent func_145748_c_() {
        return new TextComponentTranslation("container.enchant");
    }
}
