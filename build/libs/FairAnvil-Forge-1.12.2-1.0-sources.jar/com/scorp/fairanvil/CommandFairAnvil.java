package com.scorp.fairanvil;

import java.util.Locale;

import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentString;

/**
 * {@code /fairanvil <toggle|anvil|enchant|status>} - the Forge equivalent of the plugin's
 * {@code /fairanvils toggle}. Requires permission level 2 (op) by default.
 */
public class CommandFairAnvil extends CommandBase {

    @Override
    public String func_71517_b() {
        return "fairanvil";
    }

    @Override
    public String func_71518_a(ICommandSender sender) {
        return "/fairanvil <toggle|anvil|enchant|status>";
    }

    @Override
    public int func_82362_a() {
        return 2;
    }

    @Override
    public void func_184881_a(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        if (args.length == 0) {
            sender.func_145747_a(new TextComponentString(status()));
            return;
        }

        String sub = args[0].toLowerCase(Locale.ROOT);

        if (sub.equals("toggle")) {
            FairAnvilMod.enabled = !FairAnvilMod.enabled;
            sender.func_145747_a(new TextComponentString("FairAnvil " + (FairAnvilMod.enabled ? "enabled" : "disabled")));
        } else if (sub.equals("anvil")) {
            FairAnvilMod.fairAnvil = !FairAnvilMod.fairAnvil;
            sender.func_145747_a(new TextComponentString("Fair anvils " + (FairAnvilMod.fairAnvil ? "enabled" : "disabled")));
        } else if (sub.equals("enchant")) {
            FairAnvilMod.fairEnchant = !FairAnvilMod.fairEnchant;
            sender.func_145747_a(new TextComponentString("Fair enchanting " + (FairAnvilMod.fairEnchant ? "enabled" : "disabled")));
        } else if (sub.equals("status")) {
            sender.func_145747_a(new TextComponentString(status()));
        } else {
            throw new WrongUsageException(func_71518_a(sender));
        }
    }

    private static String status() {
        return "FairAnvil: " + (FairAnvilMod.enabled ? "ON" : "OFF")
                + " | anvil=" + FairAnvilMod.fairAnvil
                + " | enchant=" + FairAnvilMod.fairEnchant;
    }
}
