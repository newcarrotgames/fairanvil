package com.scorp.fairanvil;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.IInteractionObject;
import net.minecraft.world.World;

/**
 * Tells the server to open our {@link ContainerFairAnvil} while reusing the vanilla
 * {@code minecraft:anvil} GUI on the client. That is what keeps this mod server-side only:
 * the client never needs our code, it just renders its built-in anvil screen.
 */
public class FairAnvilInteractionObject implements IInteractionObject {

    private final World world;
    private final BlockPos pos;

    public FairAnvilInteractionObject(World world, BlockPos pos) {
        this.world = world;
        this.pos = pos;
    }

    @Override
    public Container func_174876_a(InventoryPlayer playerInventory, EntityPlayer playerIn) {
        return new ContainerFairAnvil(playerInventory, this.world, this.pos, playerIn);
    }

    @Override
    public String func_174875_k() {
        return "minecraft:anvil";
    }

    @Override
    public String func_70005_c_() {
        return "container.repair";
    }

    @Override
    public boolean func_145818_k_() {
        return false;
    }

    @Override
    public ITextComponent func_145748_c_() {
        return new TextComponentTranslation("container.repair");
    }
}
